/**
 * Created by jiangcheng on 2017/7/18.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (code, data, cite) {

        fox.$("#back").click(function(){
            fox.router.back();
        });

        fox.$("#upload").click(function(){

            //打开progress
            var id=fox.layer.open({
                type:4,
                content:"日志上传中"
            });
            var date=new Date();
            var remoteSavePath="log/clientLog-"+fox.settings.url;
            remoteSavePath=remoteSavePath.replace(":","_");
            var remoteFileName="log-"+date.getYear()+"-"+date.getMonth()+"-"+date.getDay()+"-"+date.getHours()+"-"+date.getMinutes()+".zip";
            var uploadFilePath="localExt://log";
            var timeout=-1;
            //为了测试进度条，所以设置pageSize比较小，单位为KB
            var pageSize=1;

            fox.http.breakpointUpload(remoteSavePath, remoteFileName, uploadFilePath, timeout, pageSize,function(code,message,data){

                if(code==0) {
                    data=JSON.parse(data);
                    var index = data["index"];
                    var count = data["totalCount"];
                    var n = 100 * index / count;
                    n= Math.ceil(n);
                    fox.layer.update(id, n);

                    if (index == count) {
                        //为了美观延时关闭
                        setTimeout(function(){
                            fox.layer.close(id);
                        },500);
                    }
                }else{
                    fox.layer.close(id);
                    fox.layer.open("日志上传失败:"+message)
                }
            });
        });

    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});