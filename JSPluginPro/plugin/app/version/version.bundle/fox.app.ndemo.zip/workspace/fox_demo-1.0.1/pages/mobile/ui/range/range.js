/**
 * Created by jiangcheng on 2017/5/21.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        fox.$('input[type="range"]').on("input",function(){
            if(this.id.indexOf('field')>=0){
                fox.$('#'+this.id+'-input').val(this.value);
            }else{
                fox.$('#'+this.id+'-val').html(this.value);
            }
        });

        fox.$("#field-range-input").on("input",function(){
            fox.$("#field-range").val(this.value);

        });

    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});