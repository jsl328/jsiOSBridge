/**
 * Created by jiangcheng on 2017/5/17.
 */
define(function(require){
    //定义路由表
    var routeTable={
        step_1:{
            html: "pages/mobile/router/step-1/step-1.html",
            css: "pages/mobile/router/step-1/step-1.css",
            js: "pages/mobile/router/step-1/step-1.js"
        },

        step_2:{
            html: "pages/mobile/router/step-2/step-2.html",
            css: "pages/mobile/router/step-2/step-2.css",
            js: "pages/mobile/router/step-2/step-2.js"
        },

        step_sub:{
            html: "pages/mobile/router/step-sub/step-sub.html",
            css: "pages/mobile/router/step-sub/step-sub.css",
            js: "pages/mobile/router/step-sub/step-sub.js"
        }
    };
    //注册路由表
    fox.router.addRouteTable(routeTable);
});