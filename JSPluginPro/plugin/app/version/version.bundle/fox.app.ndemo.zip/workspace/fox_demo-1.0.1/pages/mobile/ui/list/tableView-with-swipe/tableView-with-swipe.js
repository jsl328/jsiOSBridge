/**
 * Created by jiangcheng on 2017/6/3.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        //第一个demo，拖拽后显示操作图标，点击操作图标删除元素；
        fox.$('#my_task_1').on('tap', '.fox-btn', function(event) {
            var elem = this;
            var li = elem.parentNode.parentNode;
            //询问框
            fox.layer.open({
                content: '确认删除该条记录？'
                ,btn: ['是', '否']
                ,yes: function(index){
                    li.parentNode.removeChild(li);
                    fox.layer.close(index);
                }
                ,no:function(index){
                    setTimeout(function() {
                        fox.$.swipeoutClose(li);
                    }, 0);
                    fox.layer.close(index);
                }
            });
        });
        var btnArray = ['确认', '取消'];
        //第二个demo，向左拖拽后显示操作图标，释放后自动触发的业务逻辑
        fox.$('#my_task_2').on('slideleft', '.fox-table-view-cell', function(event) {
            var elem = this;
            //询问框
            fox.layer.open({
                content: '确认删除该条记录？'
                ,btn: ['是', '否']
                ,yes: function(index){
                    elem.parentNode.removeChild(elem);
                    fox.layer.close(index);
                }
                ,no:function(index){
                    setTimeout(function() {
                        fox.$.swipeoutClose(elem);
                    }, 0);
                    fox.layer.close(index);
                }
            });
        });
        //第二个demo，向右拖拽后显示操作图标，释放后自动触发的业务逻辑
        fox.$('#my_task_2').on('slideright', '.fox-table-view-cell', function(event) {
            var elem = this;
            //询问框
            fox.layer.open({
                content: '确认删除该条记录？'
                ,btn: ['是', '否']
                ,yes: function(index){
                    elem.parentNode.removeChild(elem);
                    fox.layer.close(index);
                }
                ,no:function(index){
                    setTimeout(function() {
                        fox.$.swipeoutClose(elem);
                    }, 0);
                    fox.layer.close(index);
                }
            });
        });

    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});