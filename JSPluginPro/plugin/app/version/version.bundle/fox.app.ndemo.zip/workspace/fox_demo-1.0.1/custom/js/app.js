define(function(require,exports){
    fox.custom=exports;
})
