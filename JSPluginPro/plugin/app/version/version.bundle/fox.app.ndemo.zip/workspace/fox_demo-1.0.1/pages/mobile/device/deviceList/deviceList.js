/**
 * Created by jiangcheng on 2017/5/24.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        //回退
        fox.$("#back").click(function(){
            fox.router.to("index")
        });

        //快捷方式跳转
        fox.$(".my-shortcut").click(function(){
            var id=this.id;
            var index=id.indexOf("_");
            var route=id.substring(0,index);
            fox.router.to(route);
        });
    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});