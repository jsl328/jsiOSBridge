/**
 * Created by jiangcheng on 2017/8/16.
 */
define(function(require,exports){

    //page加载完成后调用ready方法
    exports.ready=function(code, data, cite){

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        fox.$("#items").sortable({
            handle: ".fox-navigate-right", // 拖拽区域，默认为 items 的 子元素

            onStart: function (/**Event*/evt) { // 拖拽开始
                fox.logger.info("onStart,"+evt.item);
                var itemEl = evt.item;// 当前拖拽的html元素
            },

            onEnd: function (/**Event*/evt) { // 拖拽结束
                fox.logger.info("onEnd,"+evt.item);
                var itemEl = evt.item;
            }
        });

        fox.$("#multi").sortable({
            animation: 150, // ms, animation speed moving items when sorting, `0` — without animation
            handle: ".my-tile-name", // Restricts sort start click/touch to the specified element
            draggable: ".my-tile", // Specifies which items inside the element should be sortable
            onUpdate: function (evt/**Event*/){
                var item = evt.item; // the current dragged HTMLElement
            }
        });

        fox.$("#multi .my-tile-list").sortable({
            group: 'photo',
            animation: 150
        })

    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy=function(id,cite){

    }

});