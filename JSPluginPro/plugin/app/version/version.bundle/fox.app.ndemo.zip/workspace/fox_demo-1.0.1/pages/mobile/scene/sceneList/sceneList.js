/**
 * Created by jiangcheng on 2017/7/18.
 */
define(["./libs/iscroll/iscroll.js"],function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (code, data, cite) {

        // 菜单队列
        var menus=[];
        //加入菜单idle
        menus.push({
            text:"日志上传",
            callback:function(){
                fox.router.to("uploaddir");
            }
        });

        //加入菜单idle
        menus.push({
            text:"office",
            callback:function(){
                fox.router.to("office");
            }
        });

        //创建vm
        var vm=new Vue({
            el:"#page_base_sceneList",
            data:{
                menus:menus
            },
            methods: {
                to:function(index){
                    this.menus[index].callback();
                }
            },
            mounted:function(){
                var el=fox.$("#wrapper").get(0);
                var  myScroll = new iScroll(el, {
                    useTransform: false,
                    onBeforeScrollStart: function (e) {
                        var target = e.target;
                        while (target.nodeType != 1) target = target.parentNode;
                        if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA')
                            e.preventDefault();
                    }
                });
                fox.$("#back").click(function(){
                    var term={
                        id:"index"
                    };

                    //回退
                    fox.router.back(term);
                })
            }
        });




    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});