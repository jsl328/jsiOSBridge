/**
 * Created by jiangcheng on 2017/7/1.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        //定义vue对象
        var vm=new Vue({
            el:"#page_efficiency_rechain",
            data:{
               name_1:"",
               name_2:"",
               name_3:"",
               name_4:"",
               results:[]
            },
            methods:{
                //回退和取消
                back:function(){
                  fox.router.back();
                },

                //请求
                submit:function(){
                    //清空结果集
                    this.results=[];
                    //获取顺序请求链路
                    var sequence=fox.service.sequence();

                    //获取甲数据
                    var data_1={
                        name:this.name_1
                    };
                    //发起请求
                    sequence.request({
                        id: "service",
                        name: "trade/demo/demoService",
                        data: data_1,
                        callback: function (code, message, data) {
                            if (code == 0 || code==undefined) {
                               vm.results.push("请求:"+vm.name_1+",结果:"+data["rp"]);
                            } else {
                                fox.layer.open("service调用异常:code:" + code + ",msg:" + JSON.stringify(message));
                            }
                        }
                    });

                    //获取乙数据
                    var data_2={
                        name:this.name_2
                    };
                    //发起请求
                    sequence.request({
                        id: "service",
                        name: "trade/demo/demoService",
                        data: data_2,
                        callback: function (code, message, data) {
                            if (code == 0 || code==undefined) {
                                vm.results.push("请求:"+vm.name_2+",结果:"+data["rp"]);
                            } else {
                                fox.layer.open("service调用异常:code:" + code + ",msg:" + JSON.stringify(message));
                            }
                        }
                    });

                    //获取丙数据
                    var data_3={
                        name:this.name_3
                    };

                    //获取丁数据
                    var data_4={
                        name:this.name_4
                    };

                    //发起请求
                    sequence.request({
                        id: "service",
                        name: "trade/demo/demoService",
                        data: data_3,
                        callback: function (code, message, data) {
                            if (code == 0 || code==undefined) {
                                vm.results.push("请求:"+vm.name_3+",结果:"+data["rp"]);
                            } else {
                                fox.layer.open("service调用异常:code:" + code + ",msg:" + JSON.stringify(message));
                            }
                        }
                    }).request({
                        id: "service",
                        name: "trade/demo/demoService",
                        data: data_4,
                        callback: function (code, message, data) {
                            if (code == 0 || code==undefined) {
                                vm.results.push("请求:"+vm.name_4+",结果:"+data["rp"]);
                            } else {
                                fox.layer.open("service调用异常:code:" + code + ",msg:" + JSON.stringify(message));
                            }
                        }
                    })
                }

            }
        });



    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});