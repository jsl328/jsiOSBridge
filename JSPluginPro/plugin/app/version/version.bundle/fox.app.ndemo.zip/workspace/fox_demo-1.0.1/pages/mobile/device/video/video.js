/**
 * Created by jiangcheng on 2017/5/25.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        var vm=new Vue({
            el:"#page_device_video",
            data:{
                path:""
            },
            methods:{

                //开始录像
                startRecorder:function(){
                    //参数列表
                    var params = {
                        quality: 0,      //录像 0：低质量 1：高质量
                        maxDuration: 30000
                    };
                    //开始录音
                    fox.device.callVideo("startRecorder",function (code, message, data) {
                        if (code == 0) {
                            data = JSON.parse(data);
                            //保存路径
                            vm.path = data.path;
                            fox.logger.info("录像成功，path:"+vm.path);
                            fox.layer.open("录像成功");
                        }else{
                            fox.layer.open("录像失败");
                        }
                    },params);
                },

                //播放录音
                play:function(){
                    var s= "<source src=\""+vm.path+"\" type=\"video/mp4\">";
                    fox.$("#play").html(s);
                }

            },
            //在mounted函数中注册dom函数，因为vue会重新编译html模板
            mounted:function(){
                //回退
                fox.$("#back").click(function(){
                    var param={
                        id:"device"
                    };
                    fox.router.to("index",param);
                });
            }
        });


    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});