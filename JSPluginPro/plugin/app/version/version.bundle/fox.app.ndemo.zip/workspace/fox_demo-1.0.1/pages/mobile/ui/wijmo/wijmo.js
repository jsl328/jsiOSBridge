/**
 * Created by jiangcheng on 2017/6/3.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (id, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        // generate some random data
        var countries = 'US,Germany,UK,Japan,Italy,Greece'.split(','),
            data = [];
        for (var i = 0; i < countries.length; i++) {
            data.push({
                country: countries[i],
                downloads: Math.round(Math.random() * 20000),
                sales: Math.random() * 10000,
                expenses: Math.random() * 5000
            });
        }

        // create some onput controls
        var theCombo = new wijmo.input.ComboBox('#theCombo', {
            itemsSource: data,
            displayMemberPath: 'country'
        });
        var theDate = new wijmo.input.InputDate('#theDate', {
            value: new Date()
        });

        // create grid and show data
        var grid = new wijmo.grid.FlexGrid('#theGrid', {
            itemsSource: data,
            showMarquee: true,
            showSelectedHeaders: 'All',
            showAlternatingRows: false
        });

        // create a chart and show the same data
        var chart = new wijmo.chart.FlexChart('#theChart', {
            itemsSource: data,
            bindingX: 'country',
            series: [
                { name: 'Sales', binding: 'sales' },
                { name: 'Expenses', binding: 'expenses' },
                { name: 'Downloads', binding: 'downloads', chartType: wijmo.chart.ChartType.LineSymbols } ]
        });

        var addr = "";
        $("#test030").click(function(){

            console.log("addr:"+addr);
             fox.winshell.callService("trade/demo1/start",{
                "header": {"tellerId":"12312"},
                "body":{

                    address: addr
                }
            },function(data)
            {
                alert("返回信息"+JSON.stringify(data));

            });
        });

        $("#test031").click(function(){

            fox.winshell.getTerminalAddress(function(data)
            {
                alert("返回信息"+JSON.stringify(data));
                if(data.status)
                {
                    addr = data.address;


                    fox.winshell.callService("trade/demo1/start",{
                        "header": {"tellerId":"12312"},
                        "body":{
                            keyName:'VTS.VTS00001.zpk',
                            pinBlock:'5D6E639A2B0983A94ACA14B9B6B8AF13',
                            accountNo:'6231039901000917236',
                            //传入客户端连接地址，开始推送消息
                            address: addr
                        }
                    },function(data)
                    {
                        alert("返回信息"+JSON.stringify(data));
                    });
                }
            });
        });


        $("#test032").click(function () {
            var extEv = 'winshell.service.wijmo';
            console.log("推送接收服务："+extEv);
            fox.eventproxy.emit(extEv, "");
        });


        //注册事件
        fox.winshell.registServiceEvent("wijmo",function (data) {

            console.log("---------------->交易页面接收消息<----------");

            console.log("返回信息"+JSON.stringify(data));

            var jo = {
                "class":"wijmo",
                "command":"update",
                "content":"[" +
                "{\"country\":\"US\",\"downloads\":18836,\"expenses\":277.81404659965534,\"sales\":5887.920404409526}," +
                "{\"country\":\"Germany\",\"downloads\":17361,\"expenses\":1447.5805386246743,\"sales\":9806.22191042353}," +
                "{\"country\":\"UK\",\"downloads\":11364,\"expenses\":1470.3468207052472,\"sales\":2620.1609516409308}," +
                "{\"country\":\"Japan\",\"downloads\":692,\"expenses\":1677.6338525499202,\"sales\":7600.67923249064}," +
                "{\"country\":\"Italy\",\"downloads\":3344,\"expenses\":759.2367248818521,\"sales\":5824.589186464076}," +
                "{\"country\":\"Greece\",\"downloads\":12502,\"expenses\":62.381765805598064,\"sales\":1466.251772500058}]",
                "module":"javascript"};

            chart.itemsSource = JSON.parse(data.content);
        });

        fox.winshell.getTerminalAddress(function(data)
        {
            //alert("返回信息"+JSON.stringify(data));
            if(data.status)
            {
                addr = data.address;

                fox.winshell.callService("trade/demo1/start",{
                    "header": {"tellerId":"12312"},
                    "body":{
                        keyName:'VTS.VTS00001.zpk',
                        pinBlock:'5D6E639A2B0983A94ACA14B9B6B8AF13',
                        accountNo:'6231039901000917236',
                        //传入客户端连接地址，开始推送消息
                        address: addr
                    }
                },function(data)
                {
                    console.log("返回信息"+JSON.stringify(data));
                });
            }
        });


    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {
        fox.winshell.getTerminalAddress(function(data)
        {
            alert("返回信息"+JSON.stringify(data));
            if(data.status)
            {
                addr = data.address;

                fox.winshell.callService("trade/demo1/stop",{
                    "header": {"tellerId":"12312"},
                    "body":{
                        keyName:'VTS.VTS00001.zpk',
                        pinBlock:'5D6E639A2B0983A94ACA14B9B6B8AF13',
                        accountNo:'6231039901000917236',
                        //传入客户端连接地址，开始推送消息
                        address: addr
                    }
                },function(data)
                {
                    alert("返回信息"+JSON.stringify(data));
                });
            }
        });
    }

});