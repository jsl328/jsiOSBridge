/**
 * Created by 江成 on 2017/03/05.
 */
define(function(require){
    //定义路由表
    var routeTable={

        idle: {
            html: "pages/mobile/efficiency/idle/idle.html",
            css: "pages/mobile/efficiency/idle/idle.css",
            js: "pages/mobile/efficiency/idle/idle.js"
        },

        reqchain:{
            html: "pages/mobile/efficiency/reqchain/reqchain.html",
            css: "pages/mobile/efficiency/reqchain/reqchain.css",
            js: "pages/mobile/efficiency/reqchain/reqchain.js"
        }
    };
    //注册路由表
    fox.router.addRouteTable(routeTable);
});