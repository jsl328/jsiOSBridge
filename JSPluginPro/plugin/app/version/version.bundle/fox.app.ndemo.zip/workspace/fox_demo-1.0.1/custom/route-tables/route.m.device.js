/**
 * Created by 江成 on 2017/03/05.
 */
define(function(require){
    //定义路由表
    var routeTable={

        device: {
            html: "pages/mobile/device/deviceList/deviceList.html",
            css: "pages/mobile/device/deviceList/deviceList.css",
            js: "pages/mobile/device/deviceList/deviceList.js"
        },

        camera: {
            html: "pages/mobile/device/camera/camera.html",
            css: "pages/mobile/device/camera/camera.css",
            js: "pages/mobile/device/camera/camera.js"
        },

        audio: {
            html: "pages/mobile/device/audio/audio.html",
            css: "pages/mobile/device/audio/audio.css",
            js: "pages/mobile/device/audio/audio.js"
        },

        video: {
            html: "pages/mobile/device/video/video.html",
            css: "pages/mobile/device/video/video.css",
            js: "pages/mobile/device/video/video.js"
        },

        sign: {
            html: "pages/mobile/device/sign/sign.html",
            css: "pages/mobile/device/sign/sign.css",
            js: "pages/mobile/device/sign/sign.js"
        },

        idr: {
            html: "pages/mobile/device/idr/idr.html",
            css: "pages/mobile/device/idr/idr.css",
            js: "pages/mobile/device/idr/idr.js"
        },

        fp: {
            html: "pages/mobile/device/fp/fp.html",
            css: "pages/mobile/device/fp/fp.css",
            js: "pages/mobile/device/fp/fp.js"
        },

        pin: {
            html: "pages/mobile/device/pin/pin.html",
            css: "pages/mobile/device/pin/pin.css",
            js: "pages/mobile/device/pin/pin.js"
        },

        natives: {
            html: "pages/mobile/device/natives/natives.html",
            css: "pages/mobile/device/natives/natives.css",
            js: "pages/mobile/device/natives/natives.js"
        },

        ocr: {
            html: "pages/mobile/device/ocr/ocr.html",
            css: "pages/mobile/device/ocr/ocr.css",
            js: "pages/mobile/device/ocr/ocr.js"
        }
    };
    //注册路由表
    fox.router.addRouteTable(routeTable);
});