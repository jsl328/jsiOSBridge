/**
 * Created by jiangcheng on 2017/5/22.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        fox.$("#test").click(function(){
            //信息框
            fox.layer.open("alert测试");
        });


        fox.$("#test2").click(function(){
            //信息框
            fox.layer.open({
                content: '我是简单的弹出框'
                ,btn: '我知道了'
            });
        });


        fox.$("#test3").click(function(){
            //提示
            fox.layer.open({
                content: 'hello layer'
                ,skin: 'msg'
                ,anim:'up'
                ,time: 2 //2秒后自动关闭
            });

        });

        fox.$("#test4").click(function(){
            //询问框
            fox.layer.open({
                content: '是否刷新页面吗？'
                ,btn: ['刷新', '不要']
                ,yes: function(index){
                    location.reload();
                    fox.layer.close(index);
                }
            });
        });

        fox.$("#test5").click(function(){
            //底部对话框
            fox.layer.open({
                content: '这是一个底部弹出的询问提示'
                ,btn: ['删除', '取消']
                ,skin: 'footer'
                ,anim:'up'
                ,yes: function(index){
                    fox.layer.open({content: '执行删除操作'})
                }
                ,no:function(index){
                    fox.layer.open({content: '绝对不执行删除操作'})
                }
            });
        });

        fox.$("#test6").click(function(){

            //底部提示
            fox.layer.open({
                content: '一个没有任何按钮的底部提示'
                ,skin: 'footer'
            });

        });

        fox.$("#test7").click(function(){
            //自定义标题风格
            fox.layer.open({
                title: [
                    '我是标题',
                    'background-color: #FF4351; color:#fff;'
                ]
                ,content: '标题风格任你定义。'
            });
        });


        fox.$("#test8").click(function(){

            //页面层
            fox.layer.open({
                type: fox.layer.Custom
                ,content: '可传入任何内容，支持html。一般用于手机页面中'
                ,style: 'position:fixed; bottom:0; left:0; max-width:100%; width: 100%; height: 200px; padding:10px 0; border:none; background-color:#fff'
            });
        });

        fox.$("#test9").click(function(){
            //loading层
            fox.layer.open({type:fox.layer.Cover});
        });

        fox.$("#test10").click(function(){

            //loading带文字
            fox.layer.open({
                type: fox.layer.Cover
                ,content: '加载中',
                shadeClose:false
            });
        });

        fox.$("#test11").click(function(){
            //自定义标题风格
            var index=fox.layer.open({
               type:1
                ,content: "#myLayer"
                ,success:function(){
                   //创建vue对象
                   var vm=new Vue({
                       el:"#myDialog",
                       data:{
                           account:"",
                           pwd:""
                       },
                       methods:{
                          submit:function(){
                              //关闭对话框
                              fox.layer.close(index);
                              //提示
                              fox.layer.open({
                                  content: '账号:'+vm.account+" ,密码:"+vm.pwd
                                  ,skin: 'msg'
                                  ,anim:'up'
                                  ,time: 5 //5秒后自动关闭
                              });
                          },
                          cancel:function(){
                              //关闭对话框
                              fox.layer.close(index);
                          }
                       },
                       mounted:function(){
                           //input组件初始化
                           fox.$('.fox-input-row input').input();
                       }
                   })
                }
            });
        });

        fox.$("img").click(function(){
            var path=this.getAttribute("src");

            //image图片展示
            fox.layer.open({
                type: fox.layer.Image
                ,content: path,
                shadeClose:true
            });
        })

    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});