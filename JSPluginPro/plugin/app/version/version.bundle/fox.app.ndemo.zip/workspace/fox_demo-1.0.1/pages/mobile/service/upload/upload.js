/**
 * Created by jiangcheng on 2017/5/24.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {
        //创建vm
        var vm=new Vue({
            el:"#page_service_upload",
            methods:{
                //回退
                back:function(){
                    fox.router.to("index");
                },
                //上传文件
                upload:function(){
                    //上传文件
                    fox.service.uploadFile({
                        id:"upload",
                        name:"trade/file/upload",
                        data:{
                            file:"myFile",
                            tellerId:123,
                        },
                        callback:function(code,message,data){
                            //请求成功
                            if(code=="0"){
                                fox.layer.open("文件上传成功 response:"+data);
                            }else{
                                fox.layer.open("文件上传失败 response:"+message);
                            }
                        }
                    });
                },
                //上传大文件
                uploadBig:function(){
                    //上传大文件
                    fox.service.uploadBigFile({
                        id:"upload",
                        name:"trade/file/uploadBig",
                        data:{
                            file:"myFile",
                        },
                        callback:function(code,message,data){
                            //请求成功
                            if(code=="0"){
                                fox.layer.open("大文件上传成功 response:"+data);
                            }else{
                                fox.layer.open("大文件上传失败 response:"+message);
                            }
                        }
                    });
                }
            }
        });
    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});