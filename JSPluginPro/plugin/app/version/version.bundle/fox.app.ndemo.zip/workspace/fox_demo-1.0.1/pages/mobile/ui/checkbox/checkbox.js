/**
 * Created by jiangcheng on 2017/5/19.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        fox.$('.fox-input-group').on('change', 'input', function() {
            var value = this.checked?"true":"false";
            this.previousElementSibling.innerText = "checked："+value;
        });

    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});