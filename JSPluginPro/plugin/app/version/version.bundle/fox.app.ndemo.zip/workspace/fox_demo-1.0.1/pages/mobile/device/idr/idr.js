/**
 * Created by jiangcheng on 2017/5/27.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        var vm=new Vue({
            el:"#page_device_idr",
            methods:{
                read:function(){
                    //二代证
                    fox.device.callIdr("read",function (code, message, data) {
                        if (code == 0) {
                            fox.layer.open("二代证调用成功:" + data);
                        } else {
                            fox.layer.open("二代证调用失败:" + message);
                        }
                    })
                }

            },
            //在mounted函数中注册dom函数，因为vue会重新编译html模板
            mounted:function(){
                //回退
                fox.$("#back").click(function(){
                    var param={
                        id:"device"
                    };
                    fox.router.to("index",param);
                });
            }
        });


    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});