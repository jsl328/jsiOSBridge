/**
 * Created by 江成 on 2017/03/05.
 */
define(function(require){
    //定义路由表
    var routeTable={

        //login交易
        login: {
            html: "pages/mobile/login/login.html",
            css: "pages/mobile/login/login.css",
            js: "pages/mobile/login/login.js"
        },

        //index交易
        index: {
            html: "pages/mobile/index/index.html",
            css: "pages/mobile/index/index.css",
            js: "pages/mobile/index/index.js"
        },
        // index: {
        //     html: "pages/poc/index/index.html",
        //     css: "pages/poc/index/index.css",
        //     js: "pages/poc/index/index.js"
        // },

        //base交易
        base: {
            html: "pages/mobile/base/base.html",
            css: "pages/mobile/base/base.css",
            js: "pages/mobile/base/base.js"
        },

        ui:{
            html: "pages/mobile/ui/ui.html",
            css: "pages/mobile/ui/ui.css",
            js: "pages/mobile/ui/ui.js"
        },

        tool:{
            html: "pages/mobile/tool/tool.html",
            css: "pages/mobile/tool/tool.css",
            js: "pages/mobile/tool/tool.js"
        },

        ext:{
            html: "pages/mobile/ext/ext.html",
            css: "pages/mobile/ext/ext.css",
            js: "pages/mobile/ext/ext.js"
        },

        doc:{
            html: "pages/mobile/doc/doc.html",
            css: "pages/mobile/doc/doc.css",
            js: "pages/mobile/doc/doc.js"
        },

        efficiency:{
            html: "pages/mobile/efficiency/efficiencyList/efficiencyList.html",
            css: "pages/mobile/efficiency/efficiencyList/efficiencyList.css",
            js: "pages/mobile/efficiency/efficiencyList/efficiencyList.js"
        },

        scene:{
            html: "pages/mobile/scene/sceneList/sceneList.html",
            css: "pages/mobile/scene/sceneList/sceneList.css",
            js: "pages/mobile/scene/sceneList/sceneList.js"
        }
    };
    //注册路由表
    fox.router.addRouteTable(routeTable);
});