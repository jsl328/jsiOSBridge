/**
 * Created by jiangcheng on 2017/5/17.
 */
define(function(require){
    //定义路由表
    var routeTable={
        doc:{
            html: "pages/mobile/doc/doc.html",
            css: "pages/mobile/doc/doc.css",
            js: "pages/mobile/doc/doc.js"
        }
    };
    //注册路由表
    fox.router.addRouteTable(routeTable);
});