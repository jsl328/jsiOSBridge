﻿/**
 * Created by jiangcheng on 2017/03/05.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {
        //定义char
       var char_test1;
       //注册服务       
       fox.dataSource.register('my1',"",function(data){
 	           if(!char_test1){
 	           	  //创建chart
                char_test1 = new wijmo.chart.FlexChart('#test1', {
                    itemsSource: data,
                    bindingX: 'country',
                    series: [
                        { name: 'Sales', binding: 'sales' }]
                     });
 	          }else{
 	          	char_test1.itemSource=data;
 	          }
 	
        });
        //定义char
       var char_test2;
       //注册服务       
       fox.dataSource.register("my2","",function(data){
 	           if(!char_test2){
 	           	  //创建chart
                char_test2 = new wijmo.chart.FlexChart('#test2', {
                    itemsSource: data,
                    bindingX: 'country',
                    series: [
                        { name: 'Sales', binding: 'sales' },
                        { name: 'Expenses', binding: 'expenses' },
                        { name: 'Downloads', binding: 'downloads', chartType: wijmo.chart.ChartType.LineSymbols } ]
                     });
 	          }else{
 	          	char_test2.itemSource=data;
 	          }
 	
        });

       //定义grid
        var grid_test_grid1;
        //注册服务
        fox.dataSource.register("my3","",function(data){
            if(!grid_test_grid1){
                //创建chart
                grid_test_grid1 = new wijmo.grid.FlexGrid('#test_grid1', {
                    showAlternatingRows: false,
                    autoGenerateColumns: false,
                    headersVisibility:wijmo.grid.HeadersVisibility.None,
                    columns: [
                        { binding: 'country', header: 'Country', cssClass: 'cell-country' },
                        { binding: 'product', header: 'Product', cssClass: 'cell-product' }
                    ],
                    itemsSource: data
                });
            }else{
                grid_test_grid1.itemSource=data;
            }

        });

        //定义char
        var char_test3;
        //注册服务
        fox.dataSource.register("my4","",function(data){

            console.log("execute my4,data= "+JSON.stringify(data));
            if(!char_test3){
                //创建chart
                char_test3 = new wijmo.chart.FlexChart('#test3', {
                    itemsSource: data,
                    bindingX: 'country',
                    series: [
                        { name: 'Sales', binding: 'sales' },
                        { name: 'Expenses', binding: 'expenses' },
                        { name: 'Downloads', binding: 'downloads', chartType: wijmo.chart.ChartType.LineSymbols } ]
                });
            }else{

                console.log("-------->my4 renew datasource");
                char_test3.itemSource=data;
            }

        });


        $("#testbtn").click(function () {
            fox.dataSource.onlyforTest();

        });
        
    };



    //消息处理
    exports.onmessage = function (type, message) {

    };

     //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }
});