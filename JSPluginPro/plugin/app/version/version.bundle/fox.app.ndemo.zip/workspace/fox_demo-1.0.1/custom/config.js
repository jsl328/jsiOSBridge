/**
 * Created by 江成 on 2016/08/09.
 */

define(function(require,exports,module){

    //设置配置
    var config={
        //请求URL
        //url:"127.0.0.1:9191",
        //url:"192.168.1.100:9191",
        url:"47.92.36.166:9191",
        //是否启用SSL
        ssl:false,
        //web socket 通信方式
        webSocketType:"get",
        //默认root id
        defaultRootId:"_rootDiv",
        //开始页面
        startPage:"login",
        //录制模式
        recorderModel:false,
        //录制范围
        recorderScope:['fox.service','fox.device','fox.ext','fox.file','fox.native'],
        //调试模式
        debugModel:!fox.os.android,
        //调试范围
        debugScope:['fox.service','fox.ext','fox.file']
    };
    //保存配置
    module.exports=config;

});