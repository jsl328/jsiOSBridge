/**
 * Created by jiangcheng on 2017/5/17.
 */
define(function(require){
    //定义路由表
    var routeTable={
        serviceList:{
            html: "pages/mobile/service/serviceList/serviceList.html",
            css: "pages/mobile/service/serviceList/serviceList.css",
            js: "pages/mobile/service/serviceList/serviceList.js"
        },

        request:{
            html: "pages/mobile/service/request/request.html",
            css: "pages/mobile/service/request/request.css",
            js: "pages/mobile/service/request/request.js"
        },

        upload:{
            html: "pages/mobile/service/upload/upload.html",
            css: "pages/mobile/service/upload/upload.css",
            js: "pages/mobile/service/upload/upload.js"
        },

        download:{
            html: "pages/mobile/service/download/download.html",
            css: "pages/mobile/service/download/download.css",
            js: "pages/mobile/service/download/download.js"
        },

        websocket:{
            html: "pages/mobile/service/websocket/websocket.html",
            css: "pages/mobile/service/websocket/websocket.css",
            js: "pages/mobile/service/websocket/websocket.js"
        }
    };

    //注册路由表
    fox.router.addRouteTable(routeTable);
});