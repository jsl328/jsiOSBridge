/**
 * Created by jiangcheng on 2017/5/17.
 */
define(function(require){
    //定义路由表
    var routeTable={
        ui:{
            html: "pages/mobile/ui/uiList/uiList.html",
            css: "pages/mobile/ui/uiList/uiList.css",
            js: "pages/mobile/ui/uiList/uiList.js"
        },

        grids:{
            html: "pages/mobile/ui/grids/grids.html",
            css: "pages/mobile/ui/grids/grids.css",
            js: "pages/mobile/ui/grids/grids.js"
        },

        input:{
            html: "pages/mobile/ui/input/input.html",
            css: "pages/mobile/ui/input/input.css",
            js: "pages/mobile/ui/input/input.js"
        },

        button:{
            html: "pages/mobile/ui/button/button.html",
            css: "pages/mobile/ui/button/button.css",
            js: "pages/mobile/ui/button/button.js"
        },

        picker:{
            html: "pages/mobile/ui/picker/picker.html",
            css: "pages/mobile/ui/picker/picker.css",
            js: "pages/mobile/ui/picker/picker.js"
        },

        datetime:{
            html: "pages/mobile/ui/datetime/datetime.html",
            css: "pages/mobile/ui/datetime/datetime.css",
            js: "pages/mobile/ui/datetime/datetime.js"
        },

        checkbox:{
            html: "pages/mobile/ui/checkbox/checkbox.html",
            css: "pages/mobile/ui/checkbox/checkbox.css",
            js: "pages/mobile/ui/checkbox/checkbox.js"
        },

        radio:{
            html: "pages/mobile/ui/radio/radio.html",
            css: "pages/mobile/ui/radio/radio.css",
            js: "pages/mobile/ui/radio/radio.js"
        },

        range:{
            html: "pages/mobile/ui/range/range.html",
            css: "pages/mobile/ui/range/range.css",
            js: "pages/mobile/ui/range/range.js"
        },

        switch:{
            html: "pages/mobile/ui/switch/switch.html",
            css: "pages/mobile/ui/switch/switch.css",
            js: "pages/mobile/ui/switch/switch.js"
        },

        layer:{
            html: "pages/mobile/ui/layer/layer.html",
            css: "pages/mobile/ui/layer/layer.css",
            js: "pages/mobile/ui/layer/layer.js"
        },

        slideOut:{
            html: "pages/mobile/ui/slideOut/slideOut.html",
            css: "pages/mobile/ui/slideOut/slideOut.css",
            js: "pages/mobile/ui/slideOut/slideOut.js"
        },

        vscroll:{
            html: "pages/mobile/ui/scroll/vscroll/vscroll.html",
            css: "pages/mobile/ui/scroll/vscroll/vscroll.css",
            js: "pages/mobile/ui/scroll/vscroll/vscroll.js"
        },

        hscroll:{
            html: "pages/mobile/ui/scroll/hscroll/hscroll.html",
            css: "pages/mobile/ui/scroll/hscroll/hscroll.css",
            js: "pages/mobile/ui/scroll/hscroll/hscroll.js"
        },

        slider_default:{
            html: "pages/mobile/ui/slider/slider-default/slider-default.html",
            css: "pages/mobile/ui/slider/slider-default/slider-default.css",
            js: "pages/mobile/ui/slider/slider-default/slider-default.js"
        },

        slider_text:{
            html: "pages/mobile/ui/slider/slider-text/slider-text.html",
            css: "pages/mobile/ui/slider/slider-text/slider-text.css",
            js: "pages/mobile/ui/slider/slider-text/slider-text.js"
        },

        tableView:{
            html: "pages/mobile/ui/list/tableView/tableView.html",
            css: "pages/mobile/ui/list/tableView/tableView.css",
            js: "pages/mobile/ui/list/tableView/tableView.js"
        },

        tableView_triplex_row:{
            html: "pages/mobile/ui/list/tableView-triplex-row/tableView-triplex-row.html",
            css: "pages/mobile/ui/list/tableView-triplex-row/tableView-triplex-row.css",
            js: "pages/mobile/ui/list/tableView-triplex-row/tableView-triplex-row.js"
        },

        tableView_with_badges:{
            html: "pages/mobile/ui/list/tableView-with-badges/tableView-with-badges.html",
            css: "pages/mobile/ui/list/tableView-with-badges/tableView-with-badges.css",
            js: "pages/mobile/ui/list/tableView-with-badges/tableView-with-badges.js"
        },

        tableView_with_collapses:{
            html: "pages/mobile/ui/list/tableView-with-collapses/tableView-with-collapses.html",
            css: "pages/mobile/ui/list/tableView-with-collapses/tableView-with-collapses.css",
            js: "pages/mobile/ui/list/tableView-with-collapses/tableView-with-collapses.js"
        },

        tableView_with_input:{
            html: "pages/mobile/ui/list/tableView-with-input/tableView-with-input.html",
            css: "pages/mobile/ui/list/tableView-with-input/tableView-with-input.css",
            js: "pages/mobile/ui/list/tableView-with-input/tableView-with-input.js"
        },

        tableView_with_swipe:{
            html: "pages/mobile/ui/list/tableView-with-swipe/tableView-with-swipe.html",
            css: "pages/mobile/ui/list/tableView-with-swipe/tableView-with-swipe.css",
            js: "pages/mobile/ui/list/tableView-with-swipe/tableView-with-swipe.js"
        },

        tableView_with_media:{
            html: "pages/mobile/ui/list/tableView-with-media/tableView-with-media.html",
            css: "pages/mobile/ui/list/tableView-with-media/tableView-with-media.css",
            js: "pages/mobile/ui/list/tableView-with-media/tableView-with-media.js"
        },

        cardview:{
            html: "pages/mobile/ui/cardview/cardview.html",
            css: "pages/mobile/ui/cardview/cardview.css",
            js: "pages/mobile/ui/cardview/cardview.js"
        },

        accordion:{
            html: "pages/mobile/ui/accordion/accordion.html",
            css: "pages/mobile/ui/accordion/accordion.css",
            js: "pages/mobile/ui/accordion/accordion.js"
        },

        echarts:{
            html: "pages/mobile/ui/echarts/echarts.html",
            css: "pages/mobile/ui/echarts/echarts.css",
            js: "pages/mobile/ui/echarts/echarts.js"
        },

        sortable:{
            html: "pages/mobile/ui/sortable/sortable.html",
            css: "pages/mobile/ui/sortable/sortable.css",
            js: "pages/mobile/ui/sortable/sortable.js"
        },

        wijmo:{
            html: "pages/mobile/ui/wijmo/wijmo.html",
            css: "pages/mobile/ui/wijmo/wijmo.css",
            js: "pages/mobile/ui/wijmo/wijmo.js"
        }
    };
    //注册路由表
    fox.router.addRouteTable(routeTable);
});