/**
 * Created by jiangcheng on 2017/5/27.
 */
define(["./libs/iscroll/iscroll.js"],function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (id, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        var el=fox.$("#wrapper").get(0);
        var  myScroll = new iScroll(el, {
            useTransform: false,
            onBeforeScrollStart: function (e) {
                var target = e.target;
                while (target.nodeType != 1) target = target.parentNode;
                if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA')
                    e.preventDefault();
            }
        });
        //input组件初始化
        fox.$('.fox-input-row input').input();

    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});