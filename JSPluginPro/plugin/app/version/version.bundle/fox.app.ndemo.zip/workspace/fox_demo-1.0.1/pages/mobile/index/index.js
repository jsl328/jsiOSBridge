/**
 * Created by jiangcheng on 2017/03/05.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        var id="base";
        if(data && data.id){
            id=data.id;
        }
        //移除旧的class
        fox.$(".fox-active").removeClass("fox-active");
        //加入class
        fox.$("#"+id+"_page").addClass("fox-active");
        //路由
        fox.router.to(id,{},"contentDiv");

        //基本page
        fox.$("#base_page").click(function(){
           fox.router.to("base",{},"contentDiv");
        });
        //ui page
        fox.$("#ui_page").click(function(){
            fox.router.to("ui",{},"contentDiv");
        });
        //device page
        fox.$("#device_page").click(function(){
            fox.router.to("device",{},"contentDiv");
        });
        //document page
        fox.$("#doc_page").click(function(){
            fox.router.to("doc",{},"contentDiv");
        });
    };

    /**
     * 消息处理
     * @param type
     * @param message
     */
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});