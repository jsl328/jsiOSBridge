/**
 * Created by jiangcheng on 2017/5/24.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        var vm=new Vue({
            el:"#page_device_camera",
            methods:{
                frontTake:function(){
                    //调用前置相机
                    fox.device.callCamera("front",function(code,message,data){
                        if (code == 0) {
                            data = JSON.parse(data);
                            if (data.base64Data) {
                                var imgData = "data:image/png;base64," + data.base64Data;
                                //设置图片
                                fox.$("#pic").attr("src", imgData);
                            } else {
                                //设置图片
                                fox.$("#pic").attr("src", data.path);
                            }
                        } else {
                            fox.layer.open("拍照失败,message:" + message);
                        }
                    });
                },

                backTake:function(){
                    //参数
                    var params = {
                        maxWidth:1000, //图片最大宽度
                        maxHeight:1000,//图片最小宽度
                        quality: 70,      //图片质量 30~100
                        location: true,  //是开启定位，true为开启，false为关闭
                    };
                    //调用后置相机
                    fox.device.callCamera("back",function(code,message,data){
                        if (code == 0) {
                            data = JSON.parse(data);
                            if (data.base64Data) {
                                var imgData = "data:image/png;base64," + data.base64Data;
                                //设置图片
                                fox.$("#pic").attr("src", imgData);
                            } else {
                                //设置图片
                                fox.$("#pic").attr("src", data.path);
                            }
                        } else {
                            fox.layer.open("拍照失败,message:" + message);
                        }
                    },params);
                },

                backTakeForBase64:function(){
                    //参数
                    var params = {
                        maxWidth:1000, //图片最大宽度
                        maxHeight:1000,//图片最小宽度
                        quality: 70,    //图片质量 30~100
                        base64: true    //base64格式
                    };
                    //调用后置相机
                    fox.device.callCamera("back",function(code,message,data){
                        if (code == 0) {
                            data = JSON.parse(data);
                            if (data.base64Data) {
                                var imgData = "data:image/png;base64," + data.base64Data;
                                //设置图片
                                fox.$("#pic").attr("src", imgData);
                            } else {
                                //设置图片
                                fox.$("#pic").attr("src", data.path);
                            }
                        } else {
                            fox.layer.open("拍照失败,message:" + message);
                        }
                    },params);
                }
            },
            //在mounted函数中注册dom函数，因为vue会重新编译html模板
            mounted:function(){
                //回退
                fox.$("#back").click(function(){
                    var param={
                        id:"device"
                    };
                    fox.router.to("index",param);
                });
            }
        });


    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});