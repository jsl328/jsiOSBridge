/**
 * Created by jiangcheng on 2017/5/21.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        fox.$(".fox-table-view.fox-table-view-radio").on("selected",function(e){
            fox.$("#info").html( "当前选中的为："+e.detail.el.innerText);
        });

    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});