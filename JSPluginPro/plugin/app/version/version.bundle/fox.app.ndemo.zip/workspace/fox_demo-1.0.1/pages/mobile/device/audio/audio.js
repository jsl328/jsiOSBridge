/**
 * Created by jiangcheng on 2017/5/24.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        var vm=new Vue({
            el:"#page_device_audio",
            data:{
                path:""
            },
            methods:{

                //开始录音
                startRecorder:function(){
                    fox.$("#startRecorder").attr("disabled","true");
                    //参数列表
                    var params = {
                        maxDuration: 60000
                    };
                    //开始录音
                    fox.device.callAudio("startRecorder",function (code, message, data) {
                        if (code == 0) {
                            data = JSON.parse(data);
                            //保存路径
                            vm.path = data.path;
                            fox.logger.info("录音成功，path:"+vm.path);
                            fox.layer.open("录音成功");
                            fox.$("#startRecorder").removeAttr("disabled");
                        }else{
                            fox.layer.open("录音失败");
                            fox.$("#startRecorder").removeAttr("disabled");
                        }
                    },params);
                },

                //停止录音
                stopRecorder:function(){
                    //开始录音
                    fox.device.callAudio("stopRecorder");
                    fox.$("#startRecorder").removeAttr("disabled");

                },

                //重新录音
                reRecorder:function(){
                    //重新
                    fox.device.callAudio("reRecorder");

                },

                //播放录音
                play:function(){

                    if(fox.os.android) {
                        var params = {
                            path: vm.path
                        };
                        //调用播放
                        fox.device.callAudio("startPlay", function (code, message, data) {
                            fox.layer.open("播放完成");
                        }, params);
                    }else{
                        var s= "<source src=\""+vm.path+"\" type=\"audio/mpeg\">";
                        fox.$("#play").html(s);
                    }

                }

            },
            //在mounted函数中注册dom函数，因为vue会重新编译html模板
            mounted:function(){
                //回退
                fox.$("#back").click(function(){
                    var param={
                        id:"device"
                    };
                    fox.router.to("index",param);
                });
            }
        });


    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});