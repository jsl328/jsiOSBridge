/**
 * Created by jiangcheng on 2017/5/8.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {
        var data;
        if(cite.isBack===true){
            //获取历史数据
            data=fox.bus.get("step","step_1");
        }else{
            data={
                account:"",
                pwd:"",
                pwd2:"",
                phone:""
            }
        }

        //定义vm
        var vm=new Vue({
            el:"#page_router_step_1",
            data:data,
            methods:{
                next:function(){
                    //保存界面数据
                    fox.bus.put("step","step_1",vm.$data);
                    //定义传递参数
                    var param = {};
                    //页面跳转 参数列表为(id，data，rootId)，id:页面为唯一标志，在route table中注册;
                    //data:父亲页面要传递到子页面的数据；rootId：目标页面要嵌入的div的id
                    fox.router.to("step_2", param);
                },
                back:function(){
                    var term={
                        id:"index"
                    };

                    //回退
                    fox.router.back(term);
                },
                cancel:function(){
                    //询问框
                    fox.layer.open({
                        content: '是否退出注冊'
                        ,btn: ['是', '否']
                        ,yes: function(index){
                            fox.layer.close(index);
                            fox.router.to("index");

                        }
                    });
                }
            }
        });

        //input组件初始化
        fox.$('.fox-input-row input').input();
       
    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});