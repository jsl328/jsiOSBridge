/**
 * Created by jiangcheng on 2017/7/1.
 */
define(["./libs/iscroll/iscroll.js"],function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        var vm=new Vue({
            el:"#page_efficiency_idle",
            data:{
                styleObj:{
                    color:"black"
                },
                text:"别碰我！！！",
                count:30
            },
            methods:{
                back:function(){
                    //回退
                    fox.router.back();
                }
            }
        });

        //clock计时调用函数
        var stepFn=function(){
            vm.text="倒计时 "+vm.count+"秒";
            if(vm.count==0){
                //主动关闭计时器
                fox.idle.clearClock(id);
                //底部对话框
                fox.layer.open({
                    content: '是否回到主界面?'
                    ,btn: ['是', '否']
                    ,yes: function(index){
                        //关闭对话框
                        fox.layer.close(index);
                        //回退
                        fox.router.back();
                    }
                    ,no:function(index){
                        //关闭对话框
                        fox.layer.close(index);
                        //设置样式
                        vm.styleObj={
                            color:"black"
                        };
                        //监听到触摸事件，关闭计时
                        vm.text="再给你一次机会，不要碰我！！！";
                        // 重新注册，30秒不操作触发，触发间隔1秒
                        id=fox.idle.setClock(stepFn,startFn,stopFn,10000,1000);
                        //保存id，用于页面销毁时关闭clock
                        fox.bus.put("idle","clock",id);
                    }
                });
            }else{
                vm.count--;
            }
        };

        //clock激活时调用函数
        var startFn=function(){
            //设置倒计时30秒
            vm.count=30;
            //设置字体颜色
            vm.styleObj={
                color:"red"
            }
        };

        //clock关闭调用函数(注意该方法主只有在触发屏幕时候才会触发，而主动关闭clock不触发)
        var stopFn=function(){
            //设置样式
            vm.styleObj={
                color:"black"
            };
            //监听到触摸事件，关闭计时
            vm.text="讨厌，别再碰我！！！";
            // 重新注册，30秒不操作触发，触发间隔1秒
            id=fox.idle.setClock(stepFn,startFn,stopFn,10000,1000);
            //保存id，用于页面销毁时关闭clock
            fox.bus.put("idle","clock",id);
        };

        //30秒不操作触发，触发间隔1秒
        var id=fox.idle.setClock(stepFn,startFn,stopFn,10000,1000);
        //保存id，用于页面销毁时关闭clock
        fox.bus.put("idle","clock",id);
    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {
        //获取id
        var id=fox.bus.get("idle","clock");
        //主动关闭计时器
        fox.idle.clearClock(id);
    }

});