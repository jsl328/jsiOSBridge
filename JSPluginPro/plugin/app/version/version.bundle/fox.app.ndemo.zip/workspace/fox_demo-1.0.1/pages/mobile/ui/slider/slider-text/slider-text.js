/**
 * Created by jiangcheng on 2017/6/2.
 */
define(function(require,exports){

    //page加载完成后调用ready方法
    exports.ready=function(code, data, cite){
        //打印日志
        fox.logger.info("加载侧滑页面");


        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        fox.$('.fox-slider').slider({
            interval: 5000
        });
    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy=function(id,cite){
        //打印日志
        fox.logger.info("销毁页面");
    }

});