/**
 * Created by jiangcheng on 2017/5/24.
 */
/**
 * Created by jiangcheng on 2017/5/22.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {
        //创建vm
        var vm=new Vue({
            el:"#page_service_websocket",
            methods:{
                //回退
                back:function(){
                    fox.router.to("index");
                },
                //注册
                register:function(){
                    //注销
                    fox.service.unRegisterMessageService("demo");
                    //注册
                    fox.service.registerMessageService("demo", function (name, data) {

                        //处理information消息
                        if (data.msgType == "#info") {
                            //记录地址
                            var address = data.content;
                            fox.logger.info("1.建立连接,返回标识地址：" + address);
                            fox.service.request("trade/demo/webSocket", {"address": address}, function (code, message, content) {
                                fox.logger.info("2.标识地址记录成功:" + JSON.stringify(content));
                            });
                        }
                        else {
                            fox.layer.open("web socket通知:" + data.content);
                        }
                    });
                },
                //注销
                unRegister:function(){
                    fox.service.unRegisterMessageService("demo");
                }
            }
        });
    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});