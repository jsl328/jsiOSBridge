/**
 * Created by jiangcheng on 2017/5/30.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (id, data, cite) {
        //回退
        fox.$("#back").click(function(){
            fox.router.to("index")
        });

        //打开基础文档
        fox.$("#base_shortcut").click(function(){
            if(fox.os.android){
                fox.file.open("doc/Fox框架-基础篇.pdf");
            }else{
                fox.ext.openPDF("doc/Fox框架-基础篇.pdf");
            }

        });

        //打开document文档
        fox.$("#doc_shortcut").click(function(){
            if(fox.os.android){
                fox.file.open("doc/Fox框架-Document操作篇.pdf");
            }else{
                fox.ext.openPDF("doc/Fox框架-Document操作篇.pdf");
            }

        });

        //打开工具文档
        fox.$("#tool_shortcut").click(function(){
            if(fox.os.android){
                fox.file.open("doc/Fox框架-工具篇.pdf");
            }else{
                fox.ext.openPDF("doc/Fox框架-工具篇.pdf");
            }
        });

        //打开栅格文档
        fox.$("#grids_shortcut").click(function(){
            if(fox.os.android){
                fox.file.open("doc/Fox框架-栅格篇.pdf");
            }else{
                fox.ext.openPDF("doc/Fox框架-栅格篇.pdf");
            }
        });

    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});