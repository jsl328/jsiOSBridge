/**
 * Created by jiangcheng on 2017/5/18.
 */
define(["./libs/iscroll/iscroll.js"],function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {
        var el=fox.$("#wrapper").get(0);
        var  myScroll = new iScroll(el, {
            useTransform: false,
            onBeforeScrollStart: function (e) {
                var target = e.target;
                while (target.nodeType != 1) target = target.parentNode;
                if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA')
                    e.preventDefault();
            }
        });
        fox.$(".fox-collapse").click(function(){
            setTimeout(function(){
                //重新计算scroll的长度
                myScroll.refresh();
            },10);

        });

        //回退
        fox.$("#back").click(function(){
            fox.router.to("index")
        });

        fox.$("#grids_shortcut").click(function(){
           fox.router.to("grids");
        });

        fox.$("#input_shortcut").click(function(){
            fox.router.to("input");
        });

        fox.$("#button_shortcut").click(function(){
            fox.router.to("button");
        });

        fox.$("#checkbox_shortcut").click(function(){
            fox.router.to("checkbox");
        });

        fox.$("#radio_shortcut").click(function(){
            fox.router.to("radio");
        });

        fox.$("#range_shortcut").click(function(){
            fox.router.to("range");
        });

        fox.$("#switch_shortcut").click(function(){
            fox.router.to("switch");
        });

        fox.$("#layer_shortcut").click(function(){
            fox.router.to("layer");
        });

        fox.$("#picker_shortcut").click(function(){
            fox.router.to("picker");
        });

        fox.$("#datetime_shortcut").click(function(){
            fox.router.to("datetime");
        });

        fox.$("#slideOut_shortcut").click(function(){
            fox.router.to("slideOut");
        });

        fox.$("#vscroll_shortcut").click(function(){
            fox.router.to("vscroll");
        });

        fox.$("#hscroll_shortcut").click(function(){
            fox.router.to("hscroll");
        });

        fox.$("#slider_default_shortcut").click(function(){
            fox.router.to("slider_default");
        });

        fox.$("#slider_text_shortcut").click(function(){
            fox.router.to("slider_text");
        });

        fox.$("#tableView_shortcut").click(function(){
            fox.router.to("tableView");
        });

        fox.$("#tableView_triplex_row_shortcut").click(function(){
            fox.router.to("tableView_triplex_row");
        });

        fox.$("#tableView_with_badges_shortcut").click(function(){
            fox.router.to("tableView_with_badges");
        });

        fox.$("#tableView_with_collapses_shortcut").click(function(){
            fox.router.to("tableView_with_collapses");
        });

        fox.$("#tableView_with_input_shortcut").click(function(){
            fox.router.to("tableView_with_input");
        });

        fox.$("#tableView_with_swipe_shortcut").click(function(){
            fox.router.to("tableView_with_swipe");
        });

        fox.$("#tableView_with_media_shortcut").click(function(){
            fox.router.to("tableView_with_media");
        });

        fox.$("#cardview_shortcut").click(function(){
            fox.router.to("cardview");
        });

        fox.$("#accordion_shortcut").click(function(){
            fox.router.to("accordion");
        });

        fox.$("#echarts_shortcut").click(function(){
            fox.router.to("echarts");
        });

        fox.$("#sortable_shortcut").click(function(){
            fox.router.to("sortable");
        });

        fox.$("#wijmo_shortcut").click(function(){
            fox.router.to("wijmo");
        });
    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});