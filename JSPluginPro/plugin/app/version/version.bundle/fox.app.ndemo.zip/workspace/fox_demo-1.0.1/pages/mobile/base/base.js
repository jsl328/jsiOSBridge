/**
 * Created by jiangcheng on 2017/5/8.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        //路由测试
        fox.$("#router_shortcut").click(function(){
           fox.router.to("step_1")
        });

        //路由测试
        fox.$("#service_shortcut").click(function(){
            fox.router.to("serviceList")
        });
        
        //工具操作说明
        fox.$("#tool_shortcut").click(function(){
            var s=window.location.href;
            var index=s.lastIndexOf("/");
            var url=s.substring(0,index)+"/doc/html/tool.htm";
            fox.ext.openURL(url);
        });

        //document操作说明
        fox.$("#dom_shortcut").click(function(){
            var s=window.location.href;
            var index=s.lastIndexOf("/");
            var url=s.substring(0,index)+"/doc/html/query.htm";
            fox.ext.openURL(url);
        });

        //效率测试
        fox.$("#efficiency_shortcut").click(function(){
            fox.router.to("efficiency")
        });

        //场景测试
        fox.$("#scene_shortcut").click(function(){
            fox.router.to("scene")
        });

    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});