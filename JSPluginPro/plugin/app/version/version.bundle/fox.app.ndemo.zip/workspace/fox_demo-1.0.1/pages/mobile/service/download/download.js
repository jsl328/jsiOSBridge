/**
 * Created by jiangcheng on 2017/5/24.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {
        //创建vm
        var vm=new Vue({
            el:"#page_service_download",
            methods: {
                //回退
                back: function () {
                    fox.router.to("index");
                },
                //上传文件
                download: function () {
                    //服务名
                    var serviceName="trade/file/download";
                    var fileName="test.png";
                    var args={
                        path:serviceName
                    };
                   var url=fox.service.getRequestUrl(args);
                   url+="?fileName="+fileName;
                   window.open(url);
                }
            }
        });
    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});