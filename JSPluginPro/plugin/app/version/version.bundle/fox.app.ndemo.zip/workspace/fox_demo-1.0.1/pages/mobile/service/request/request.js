/**
 * Created by jiangcheng on 2017/5/22.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {
        //创建vm
        var vm=new Vue({
             el:"#page_service_request",
             data:{
                name:"",
                rp:""
             },

             methods:{
                 //回退
                 back:function(){
                     fox.router.to("index");
                 },
                 //提交
                 submit:function(){
                     //请求service
                     //参数列表json对象
                     //     {
                     //      id:服务Id （可选，建议为每个页面的服务指定一个唯一id）
                     //      name:服务名
                     //      data:请求数据
                     //      callback:回调函数
                     //      }
                     // 回调函数 参数列表code,message,data
                     // code:0代表成功，1：代表取消 2：代表失败
                     // message:当服务异常的时候返回错误信息
                     // data：但服务成功时返回数据
                     fox.service.request({
                         id: "service",
                         name: "trade/demo/demoService",
                         data: vm.$data,
                         callback: function (code, message, data) {
                             if (code == 0 || code==undefined) {
                                 var rp = data["rp"];
                                 vm.rp = rp;
                             } else {
                                 fox.layer.open("service调用异常:code:" + code + ",msg:" + JSON.stringify(message));
                             }
                         }
                     });
                 },
                 //取消
                 cancel:function(){
                     fox.router.to("index");
                 }
             }
        });
    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});