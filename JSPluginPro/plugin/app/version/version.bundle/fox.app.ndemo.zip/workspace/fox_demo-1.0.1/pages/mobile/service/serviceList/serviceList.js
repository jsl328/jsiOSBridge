/**
 * Created by jiangcheng on 2017/5/17.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        //回退
        fox.$("#back").click(function(){
            fox.router.to("index")
        });

        fox.$("#request_shortcut").click(function(){
            fox.router.to("request");

        });

        fox.$("#upload_shortcut").click(function(){
            fox.router.to("upload");

        });

        fox.$("#download_shortcut").click(function(){
            fox.router.to("download");

        });

        fox.$("#websocket_shortcut").click(function(){
            fox.router.to("websocket");

        });

    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});