/**
 * Created by 江成 on 2017/03/05.
 */
define(function(require){
    //定义路由表
    var routeTable={

        uploaddir: {
            html: "pages/mobile/scene/uploaddir/uploaddir.html",
            css: "pages/mobile/scene/uploaddir/uploaddir.css",
            js: "pages/mobile/scene/uploaddir/uploaddir.js"
        },

        office: {
            html: "pages/mobile/scene/office/office.html",
            css: "pages/mobile/scene/office/office.css",
            js: "pages/mobile/scene/office/office.js"
        }

    };
    //注册路由表
    fox.router.addRouteTable(routeTable);
});