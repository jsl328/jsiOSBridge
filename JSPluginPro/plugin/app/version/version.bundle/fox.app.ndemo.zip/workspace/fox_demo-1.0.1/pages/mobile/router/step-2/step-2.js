/**
 * Created by jiangcheng on 2017/5/8.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {
        //1.打开子页面，2.并向子页面发送消息
        fox.router.to("step_sub",{},"subContentDiv").done(function(){
            fox.router.sendMessage("step_sub","notify","恭喜您，注册成功");
        });

        fox.$("#back").click(function(){
            var term={
                before:'step_2'
            };
            fox.router.back(term);
        });

        fox.$("#previous").click(function(){
            var term={
                id:'step_1'
            };
            fox.router.back(term);
            //fox.router.to("step_1");
        });

        fox.$("#finish").click(function(){
            //清空数据
            fox.bus.remove("step");
            fox.router.to("index");
        });



    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});