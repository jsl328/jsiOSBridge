/**
 * Created by jiangcheng on 2017/5/22.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        //初始化swith
        fox.$(".fox-switch").switch();

        fox.$('.fox-content .fox-switch').each(function() { //循环所有toggle
            //toggle.classList.contains('fox-active') 可识别该toggle的开关状态
            this.parentNode.querySelector('span').innerText = '状态：' + (fox.$(this).hasClass('fox-active') ? 'true' : 'false');
            /**
             * toggle 事件监听
             */
            fox.$(this).toggle(function(event) {
                //event.detail.isActive 可直接获取当前状态
                this.parentNode.querySelector('span').innerText = '状态：' + (event.detail.isActive ? 'true' : 'false');
            });
        });

    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});