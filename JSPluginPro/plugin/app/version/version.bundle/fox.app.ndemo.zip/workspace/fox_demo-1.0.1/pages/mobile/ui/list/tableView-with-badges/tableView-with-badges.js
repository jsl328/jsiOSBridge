/**
 * Created by jiangcheng on 2017/6/3.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        //初始化swith
        fox.$(".fox-switch").switch();

        fox.$("#myToggle").toggle(function(event){
            var isActive = event.detail.isActive;
            var table = fox.$('.fox-table-view').get(0);
            var card = fox.$('.fox-card').get(0);
            if (isActive) {
                 card.appendChild(table);
                 card.style.display = '';
            } else {
                 var content = fox.$('.fox-content').get(0);
                 content.insertBefore(table, card);
                 card.style.display = 'none';
            }

        })


    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});