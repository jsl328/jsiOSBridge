/**
 * Created by jiangcheng on 2017/5/18.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });
        //input组件初始化
        fox.$('.fox-input-row input').input();

        /**
         * 双击触发
         */
        fox.$("#speech").doubletap(function(){
            fox.ext.startRecognize(function(code,message,data){
                if(code==0) {
                    fox.$("#speech").val(data);
                }else{
                    fox.layer.open("code:"+code+",message:"+message);
                }
            });
        })

    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});