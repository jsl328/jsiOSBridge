/**
 * Created by jiangcheng on 2017/5/31.
 */
define(["./custom/js/city.data.js","./custom/js/city.data-3.js"],function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        fox.$("#back").click(function(){
            var param={
                id:"ui"
            };
            fox.router.to("index",param);
        });

        /**
         * 获取对象属性的值
         * 主要用于过滤三级联动中，可能出现的最低级的数据不存在的情况，实际开发中需要注意这一点；
         * @param {Object} obj 对象
         * @param {String} param 属性名
         */
        var _getParam = function(obj, param) {
            return obj[param] || '';
        };
        //普通示例
        var userPicker = new fox.$.PopPicker();
        userPicker.setData([{
            value: 'ywj',
            text: '董事长 叶文洁'
        }, {
            value: 'aaa',
            text: '总经理 艾AA'
        }, {
            value: 'lj',
            text: '罗辑'
        }, {
            value: 'ymt',
            text: '云天明'
        }, {
            value: 'shq',
            text: '史强'
        }, {
            value: 'zhbh',
            text: '章北海'
        }, {
            value: 'zhy',
            text: '庄颜'
        }, {
            value: 'gyf',
            text: '关一帆'
        }, {
            value: 'zhz',
            text: '智子'
        }, {
            value: 'gezh',
            text: '歌者'
        }]);
        fox.$("#showUserPicker").click(function(event) {
            userPicker.show(function(items) {
                fox.$("#userResult").html(JSON.stringify(items[0]));
                //返回 false 可以阻止选择框的关闭
                //return false;
            });
        });
        //-----------------------------------------
        //级联示例
        var cityPicker = new fox.$.PopPicker({
            layer: 2
        });
        cityPicker.setData(cityData);
        fox.$("#showCityPicker").click(function(event) {
            cityPicker.show(function (items) {
                fox.$("#cityResult").html("你选择的城市是:" + items[0].text + " " + items[1].text);
                //返回 false 可以阻止选择框的关闭
                //return false;
            })
        });
        //-----------------------------------------
        //					//级联示例
        var cityPicker3 = new fox.$.PopPicker({
            layer: 3
        });
        cityPicker3.setData(cityData3);
       fox.$("#showCityPicker3").click(function(event) {
            cityPicker3.show(function(items) {
                fox.$("#cityResult3").html("你选择的城市是:" + _getParam(items[0], 'text') + " " + _getParam(items[1], 'text') + " " + _getParam(items[2], 'text'));
                //返回 false 可以阻止选择框的关闭
                //return false;
            });
        });
    };

    //消息处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});