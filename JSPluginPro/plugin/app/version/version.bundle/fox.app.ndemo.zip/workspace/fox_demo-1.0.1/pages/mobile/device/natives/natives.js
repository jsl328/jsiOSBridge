/**
 * Created by jiangcheng on 2017/8/18.
 */
define(function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (hashCode, data, cite) {

        var vm=new Vue({
            el:"#page_device_natives",
            data:{
                enabled:false,
                stepLocTxt:"开启自动定位",
                number:"10010"
            },
            methods:{
                stepLocation:function(){
                    vm.enabled=!vm.enabled;
                    fox.native.setAutoUpdateLocation(vm.enabled);
                    if(vm.enabled==true){
                        vm.stepLocTxt="关闭自动定位";
                    }else{
                        vm.stepLocTxt="开启自动定位";
                    }
                },
                checkWifi:function(){
                    fox.native.checkWifi(function(code,message,data){
                        if(code==0){
                            fox.layer.open("检查WIFI状态成功:"+data);
                        }else{
                            fox.layer.open("检查WIFI状态失败:"+message);
                        }
                    })
                },
                getLocation:function(){
                    fox.native.getLocation(function(code,message,data){
                        if(code==0){
                            fox.layer.open("获取位置信息成功:"+data);
                        }else{
                            fox.layer.open("获取位置信息失败:"+message);
                        }
                    })
                },
                getIP:function(){
                    fox.native.getLocalIP(function(code,message,data){
                        if(code==0){
                            fox.layer.open("获取IP成功:"+data);
                        }else{
                            fox.layer.open("获取IP失败:"+message);
                        }
                    })
                },
                getMac:function(){
                    fox.native.getLocalMac(function(code,message,data){
                        if(code==0){
                            fox.layer.open("获取Mac成功:"+data);
                        }else{
                            fox.layer.open("获取Mac失败:"+message)
                        }
                    })
                },
                stopApp:function(){
                    fox.native.shutdown();
                },
                restartApp:function(){
                    fox.native.restart();
                },
                getVersion:function(){
                    fox.native.getVersion(function(code,message,data){
                        if(code==0){
                            fox.layer.open("获取version成功:"+data);
                        }else{
                            fox.layer.open("获取version失败:"+message)
                        }
                    })
                },
                getIMEI:function(){
                    fox.native.getIMEI(function(code,message,data){
                        if(code==0){
                            fox.layer.open("获取IMEI成功:"+data);
                        }else{
                            fox.layer.open("获取IMEI失败:"+message);
                        }
                    })
                },
                getIMSI:function(){
                    fox.native.getIMSI(function(code,message,data){
                        if(code==0){
                            fox.layer.open("获取IMSI成功:"+data);
                        }else{
                            fox.layer.open("获取IMSI失败:"+message);
                        }
                    })
                },
                getNumber:function(){
                    fox.native.getNumber(function(code,message,data){
                        if(code==0){
                            fox.layer.open("获取number成功:"+data);
                        }else{
                            fox.layer.open("获取number失败:"+message);
                        }
                    })
                },
                notice:function(){
                    var param={
                        contentTitle:"Fox消息",
                        contentText:"测试测试"+new Date(),
                        subText:"",
                        ticker:""
                    };
                    fox.native.notify(param,function(code,message,data){
                        if(code==0){
                            fox.layer.open("通知成功");
                        }else{
                            fox.layer.open("通知失败:"+message)
                        }
                    })
                },
                callPhone:function() {
                    var param = {
                        number: vm.number
                    };
                    fox.native.callPhone(param, function (code, message, data) {
                        if (code == 0) {
                            fox.logger.info("打电话成功");
                            alert("message"+message+",data:"+JSON.stringify(data))
                        } else {
                            fox.layer.open("打电话失败:" + message)
                        }
                    })
                },
                endPhone:function () {
                    fox.native.endPhone({},function (code,message,data) {
                        if (code == 0) {
                            fox.logger.info("挂电话成功");
                        } else {
                            fox.layer.open("打电话失败:" + message)
                        }
                    })
                }

            },
            //在mounted函数中注册dom函数，因为vue会重新编译html模板
            mounted:function(){
                //input组件初始化
                fox.$('.fox-input-row input').input();

                //回退
                fox.$("#back").click(function(){
                    var param={
                        id:"device"
                    };
                    fox.router.to("index",param);
                });
            }
        });


    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});