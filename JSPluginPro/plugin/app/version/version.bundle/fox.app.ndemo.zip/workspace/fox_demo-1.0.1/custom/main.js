/**
 * Created by jiangcheng on 2016/08/09.
 */
(function (window, fox) {

    //fox配置
    fox.config({
        //path配置
        paths: {
            'plugins': './libs/plugins'
        },
        // 别名配置
        alias: {
            'config': './custom/config.js',
            'vue': './libs/vue-2.2.6/vue.js',
            'jquery': './libs/jquery-2.2.3/jquery.js'
        },
        // 文件编码
        charset: 'UTF-8',

        //事件是否监听参数
        gestureConfig: {
            tap: true,
            doubletap: true,
            longtap: true,
            hold: false,
            flick: true,
            swipe: true,
            drag: true,
            pinch: false
        }

    });

    //css依赖库
    var libs_css = [
        "./libs/fox-ui-0.5/base/css/grids.css",
        "./libs/fox-ui-0.5/base/css/grids-responsive.css",
        "./libs/fox-ui-0.5/mui/css/mui.css",
        "./libs/fox-ui-0.5/mui/css/mui.picker.css",
        "./libs/fox-ui-0.5/mui/css/mui.dtpicker.css",
        "./libs/fox-ui-0.5/mui/css/mui.poppicker.css",
        "./libs/fox-ui-0.5/mui/css/icons-extra.css",
        "./libs/fox-ui-0.5/mui/css/mui.layer.css",
        "./custom/css/app.css",
        //---------------wijmo-----------------------   //
        "./libs/plugins/wijmo/styles/vendor/wijmo.min.css"
    ];

    //js依赖库
    var libs_js = [
        "config",
        "vue",
        "jquery",
        //----------------fox ui ------------------//
        "./libs/fox-ui-0.5/base/js/base.js",
        "./libs/fox-ui-0.5/base/js/base.slide.js",
        "./libs/fox-ui-0.5/mui/js/mui.js",
        "./libs/fox-ui-0.5/mui/js/mui.picker.js",
        "./libs/fox-ui-0.5/mui/js/mui.poppicker.js",
        "./libs/fox-ui-0.5/mui/js/mui.dtpicker.js",
        "./libs/fox-ui-0.5/mui/js/mui.layer.js",
        "./libs/fox-ui-0.5/mui/js/mui.sortable.js",
        "./custom/js/app.js",
        //---------------fox插件---------------------//
        "./libs/plugins/fox/fox.settings.js",
        "./libs/plugins/fox/fox.base64.js",
        "./libs/plugins/fox/fox.callproxy.js",
        "./libs/plugins/fox/fox.sessionstorage.js",
        "./libs/plugins/fox/fox.localstorage.js",
        "./libs/plugins/fox/fox.idle.js",
        "./libs/plugins/fox/fox.service.js",
        "./libs/plugins/fox/fox.device.js",
        "./libs/plugins/fox/fox.http.js",
        "./libs/plugins/fox/fox.file.js",
        "./libs/plugins/fox/fox.native.js",
        "./libs/plugins/fox/fox.ext.js",
        "./libs/plugins/fox/fox.validate.js",
        //"./libs/plugins/fox/fox.winshell.js",
        "./libs/plugins/fox/fox.datasource.js",
        //--------------- just fo Mobile UI -------------------//
        "./libs/plugins/fox/fox.plus.js",

        //---------------wijmo-----------------------   //
        "./libs/plugins/wijmo/scripts/vendor/wijmo.min.js",
        "./libs/plugins/wijmo/scripts/vendor/wijmo.input.min.js",
        "./libs/plugins/wijmo/resources/wijmo.grid.min.js",
        "./libs/plugins/wijmo/resources/wijmo.chart.min.js"


    ];

    //路由表
    var route_tables = [
          "./custom/route-tables/route.mobile.js",
         "./custom/route-tables/route.m.router.js",
         "./custom/route-tables/route.m.service.js",
         "./custom/route-tables/route.m.ui.js",
         "./custom/route-tables/route.m.device.js",
         "./custom/route-tables/route.m.efficiency.js"
         //"./custom/route-tables/route.m.scene.js"
    ];

    //合并lib
    var libs = libs_css.concat(libs_js, route_tables);
    fox.require.use(libs).done(function () {
        //fox别名
        window.fx = window.fox;
        //导入配置
        var config = fox.require.require("config");

        //设置配置
        fox.settings.config(config);

        //加入请求过滤器
        fox.service.addFilter({

            //过滤器名称
            name: "messageParser",

            //请求前触发
            before: function (event) {
                //定义请求头
                var header = {};
                //定义请求数据
                var reqData = {
                    //请求头
                    header: header,
                    //请求数据
                    data: event.data
                };
                //保存导出数据
                event.code = 0;
                event.data = reqData;
                //返回处理标志，true则继续处理，false则中断处理
                return true;
            },

            //数据返回后触发
            after: function (event) {

                //只处理JSON对象
                if (fox.type(event.data) == "object" && fox.type(event.data.header)!="undefined") {
                    //获取响应头
                    var rspHeader = event.data.header;
                    //获取响应数据
                    var rspData = event.data.data;

                    if (fox.type(rspHeader.code) == "undefined" || rspHeader.code == 0) {
                        //保存导出数据
                        event.code = 0;
                        event.message = "";
                        event.data = rspData;
                        //返回处理标志，true则继续处理，false则中断处理
                        return true;
                    } else {
                        //保存导出数据
                        event.code = rspHeader.code;
                        event.message = rspHeader.msg;
                        event.data = rspData;
                        //返回处理标志，true则继续处理，false则中断处理
                        return true;
                    }
                }

                //返回处理标志，true则继续处理，false则中断处理
                return true;
            },

            //异常发生后触发
            exception: function (event) {
                //获取url
                var url = window.location.toString();
                if ("unlogin" == event.message) {
                    //修改默认root div
                    router.setDefaultRootId("_rootDiv");
                    var index = url.indexOf("#!");
                    if (index != -1) {
                        url = url.substring(0, index);
                    }
                    url += "#!login";
                    var data = new Date();
                    url += "?time=";
                    url += data.getTime();
                    window.location = url;
                    //返回处理标志，true则继续处理，false则中断处理
                    return false;
                }
                //重复提交处理
                if ("resubmit" == event.message) {
                    fox.logger.error("resubmit error");
                    //返回处理标志，true则继续处理，false则中断处理
                    return false;
                }

                //返回处理标志，true则继续处理，false则中断处理
                return true;
            }
        });

        //设置默认root id
        fox.router.setDefaultRootId(config.defaultRootId);
        //加入路由过滤器
        fox.router.addFilter({

            /**
             * 过滤器名称
             */
            name: "default",

            /**
             * 路由跳转前执行
             * @param code
             * @param cite
             */
            before:function(code, cite){
                return true;
            },

            /**
             * 加载路由内容前执行
             * @param code
             * @param cite
             */
            mount:function(code,cite){

            },

            /**
             * ready函数执行
             * @param exports
             * @param code
             * @param data
             * @param cite
             */
            ready: function (exports, code, data, cite) {

            },

            /**
             * 卸载路由内容前执行
             * @param code
             * @param cite
             */
            unMount:function(code,cite){

            },

            /**
             * destroy函数执行
             * @param exports
             * @param code
             * @param cite
             */
            destroy: function (exports, code, cite) {

            }

        });


        //创建hash处理事件
        var hashFn=function(defaultHash){

            var sIndex = location.hash.indexOf("!");
            var eIndex = location.hash.indexOf("?");

            if (sIndex != -1) {
                //定义hash
                var hash = "";
                //定义data
                var data = {};

                if (eIndex == -1) {
                    //获取hash
                    hash = location.hash.slice(sIndex + 1);
                } else {
                    //获取hash
                    hash = location.hash.substring(sIndex + 1, eIndex);
                    var queryStr = location.hash.slice(eIndex + 1);
                    var items = queryStr.split("&");
                    //解析数据
                    for (var i = 0; i < items.length; i++) {
                        var ss = items[i].split("=");
                        data[ss[0]] = ss[1];
                    }
                }
                fox.logger.info("触发hash事件,hash:" + hash);
                //路由跳转
                fox.router.to(hash, data);

            }else if(defaultHash){
                //路由跳转
                fox.router.to(defaultHash);
            }

        };
        //添加hash change事件
        if (window.addEventListener) {
            window.addEventListener("hashchange", hashFn, false);
        }
        else if (window.attachEvent) {
            window.attachEvent("on" + "hashchange", hashFn);
        }
        else {
            window["on" + "hashchange"] = hashFn;
        }

        //页面跳转
        hashFn(config.startPage);
    })

}(window, fox));