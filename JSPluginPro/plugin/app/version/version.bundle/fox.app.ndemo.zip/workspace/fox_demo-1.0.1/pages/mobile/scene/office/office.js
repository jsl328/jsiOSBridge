/**
 * Created by jiangcheng on 2017/8/8.
 */
define(["./libs/iscroll/iscroll.js"],function (require, exports) {

    //page加载完成后调用ready方法
    exports.ready = function (code, data, cite) {

        var index=0;
        var fn=function(code,message,data){
            //关闭输出层
            fox.layer.close(index);
            if(code==0) {
                var url=fox.http._getAddress()+"/"+data;
                //打开页面
                fox.ext.openURL(url);
            }else{
                fox.layer.open(message);
            }

        };

        // 菜单队列
        var menus=[];
        menus.push({
            text:"测试文档.wps",
            callback:function(){
                //loading带文字
                index= fox.layer.open({
                    type: fox.layer.Cover
                    ,content: '文件加载中',
                    shadeClose:false
                });

                var remotePath="services/trade/office/convert.do";
                var savePath="upload/office";
                var fileName="测试文档.wps";
                var uploadFilePath="wps/测试文档.wps";
                var timeout=-1;
                fox.http.directUpload(remotePath,savePath,fileName,uploadFilePath,timeout,fn);
            }
        });

        menus.push({
            text:"测试文档.et",
            callback:function(){
                //loading带文字
                index= fox.layer.open({
                    type: fox.layer.Cover
                    ,content: '文件加载中',
                    shadeClose:false
                });

                var remotePath="services/trade/office/convert.do";
                var savePath="upload/office";
                var fileName="测试文档.et";
                var uploadFilePath="wps/测试文档.et";
                var timeout=-1;
                fox.http.directUpload(remotePath,savePath,fileName,uploadFilePath,timeout,fn);
            }
        });

        menus.push({
            text:"测试文档.dps",
            callback:function(){
                //loading带文字
                index= fox.layer.open({
                    type: fox.layer.Cover
                    ,content: '文件加载中',
                    shadeClose:false
                });

                var remotePath="services/trade/office/convert.do";
                var savePath="upload/office";
                var fileName="测试文档.dps";
                var uploadFilePath="wps/测试文档.dps";
                var timeout=-1;
                fox.http.directUpload(remotePath,savePath,fileName,uploadFilePath,timeout,fn);
            }
        });

        menus.push({
            text:"测试文档.txt",
            callback:function(){
                //loading带文字
                index= fox.layer.open({
                    type: fox.layer.Cover
                    ,content: '文件加载中',
                    shadeClose:false
                });

                var remotePath="services/trade/office/convert.do";
                var savePath="upload/office";
                var fileName="测试文档.txt";
                var uploadFilePath="wps/测试文档.txt";
                var timeout=-1;
                fox.http.directUpload(remotePath,savePath,fileName,uploadFilePath,timeout,fn);
            }
        });

        menus.push({
            text:"测试文档.pdf",
            callback:function(){
                //loading带文字
                index= fox.layer.open({
                    type: fox.layer.Cover
                    ,content: '文件加载中',
                    shadeClose:false
                });

                var remotePath="services/trade/office/convert.do";
                var savePath="upload/office";
                var fileName="测试文档.pdf";
                var uploadFilePath="wps/测试文档.pdf";
                var timeout=-1;
                fox.http.directUpload(remotePath,savePath,fileName,uploadFilePath,timeout,fn);
            }
        });

        //创建vm
        var vm=new Vue({
            el:"#page_scene_office",
            data:{
                menus:menus
            },
            methods: {
                to:function(index){
                    this.menus[index].callback();
                }
            },
            mounted:function(){
                var el=fox.$("#wrapper").get(0);
                var  myScroll = new iScroll(el, {
                    useTransform: false,
                    onBeforeScrollStart: function (e) {
                        var target = e.target;
                        while (target.nodeType != 1) target = target.parentNode;
                        if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA')
                            e.preventDefault();
                    }
                });
                fox.$("#back").click(function(){
                    var term={
                        id:"index"
                    };

                    //回退
                    fox.router.back(term);
                })
            }
        });


    };

    //消息通知处理
    exports.onmessage = function (type, message) {

    };

    //page销毁时触发destroy方法
    exports.destroy = function (id, cite) {

    }

});